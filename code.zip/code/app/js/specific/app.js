$(document).ready(function() {

	(function() {

		if ( $('.c-block').length ) {

		}
	})();
});

$(window).on( 'load', function() {

	(function() {

		if ( $('.c-block').length ) {
		}
	})();
});